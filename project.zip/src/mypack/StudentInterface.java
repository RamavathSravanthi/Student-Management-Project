package mypack;

public interface StudentInterface {
	
	public void Viewcourses();
	public void ViewStatus();
	public void ViewBalance();
	public void paidfee(double paidfee);
	
}
